import React from 'react'

import  image1 from '../../../assets/img/testimonials/hero-bg.jpg'
const Hero = () => {
  return (
    <div className='main'>
      
    <section id="hero" class="hero section dark-background">

      <img src={image1} alt="" data-aos="fade-in" class=""/>

      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <h2>Abbey</h2>
        <p>I'm <span class="typed" data-typed-items="Designer, Developer, Freelancer, Photographer">Full stack website developer</span><span class="typed-cursor typed-cursor--blink" aria-hidden="true"></span><span class="typed-cursor typed-cursor--blink" aria-hidden="true"></span></p>
      </div>

    </section>
    </div>
  )
}

export default Hero
